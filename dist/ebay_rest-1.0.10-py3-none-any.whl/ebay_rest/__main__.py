# __main__.py


def main():
    """Guide someone trying to run this at the command line."""
    print(
        "This package conveniently wraps eBay’s REST APIs."
        "\nLearn more at https://github.com/matecsaj/ebay_rest."
    )


if __name__ == "__main__":
    main()
